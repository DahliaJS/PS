#include <iostream>

using namespace std;

int main() {
  char c = '10';
  cout << int(c);
}