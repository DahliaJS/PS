//BOJ 10989 - 수 정렬하기 3 메모리 초과

/* short 써도 메모리 초과
#include <iostream>
#include <set>

using namespace std;

int main() {
	int N;
	short t;
	cin >> N;
	multiset<short> s;
	multiset<short>::iterator iter;
	for(int i=0; i<N; i++) {
		cin >> t;
		s.insert(t);
	}

	for(iter=s.begin(); iter!=s.end(); iter++)
		cout << *iter << '\n';

	return 0;
}
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
	ios_base::sync_with_stdio(false);
	cin.tie(0);

	int N;
	short t;
	cin >> N;
	vector<short> v;
	for(int i=0; i<N; i++) {
		cin >> t;
		v.push_back(t);
	}
	sort(v.begin(), v.end());

	for(int i=0; i<v.size(); i++)
		cout << v[i] << '\n';

	return 0;
}